

<?php
$page = 'Jajan';
?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="row mb-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body" style="background-color: #8DA0F5">
                        <h5>Saldo: <?php echo e($saldo->saldo); ?></h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header" style="background-color: #64B9F0; font-weight: bold; color: white">Menu</div>
                    <div class="card-body">
                        <div class="row">
                            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col col-md-3 mt-4" >
                                    <div class="card" style="border-color: black">
                                        <div class="card-body">
                                            <td>
                                                <img width="150" height="80" style="margin: 20px" src=<?php echo e(asset('assets/images/' . $barang->image)); ?>

                                                    alt="not found" />
                                            </td>
                                            <div class="card-title"><?php echo e($barang->name); ?></div>
                                            <div>
                                                <?php echo e($barang->desc); ?>

                                                <p>
                                                    Price: <?php echo e($barang->price); ?>

                                                </p>
                                            </div>
                                        </div>
                                        <form class="m-2" method="POST"
                                            action="<?php echo e(route('addToCart', ['id' => $barang->id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="number" name="jumlah" class="form-control" value="1">
                                            <input type="hidden" name="barang_id" value="<?php echo e($barang->id); ?>">
                                            <button class="btn btn-primary mt-2" type="submit">Tambah Ke Keranjang</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br/>
            <div class="card">
                <div class="card-header" style="background-color: #64B9F0; font-weight: bold; color: white">keranjang <?php echo e(count($carts) > 0 ? '#' . $carts[0]->invoice_id : ''); ?></div>
                <div class="card-body">
                    <table class="table table-bordered table-striped" >
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Barang</th>
                                <th>Harga</th>
                                <th>Qty</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr >
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($cart->barang->name); ?></td>
                                    <td><?php echo e($cart->barang->price); ?></td>
                                    <td><?php echo e($cart->jumlah); ?></td>
                                    <td><?php echo e($cart->barang->price * $cart->jumlah); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5">Total : <?php echo e($total_cart); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary">Checkout</a>
                </div>
            </div>
        </div>
        <br/>
            <div class="container">
                <div class="card">
                    <div class="card-header" style="background-color: #64B9F0; font-weight: bold; color: white">Checkout <?php echo e(count($carts) > 0 ? '#' . $carts[0]->invoice_id : ''); ?></div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Barang</th>
                                    <th>Harga</th>
                                    <th>Qty</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $checkouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $checkout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($checkout->barang->name); ?></td>
                                        <td><?php echo e($checkout->barang->price); ?></td>
                                        <td><?php echo e($checkout->jumlah); ?></td>
                                        <td><?php echo e($checkout->barang->price * $checkout->jumlah); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="5">Total : <?php echo e($total_checkout); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('bayar')); ?>" class="btn btn-primary">Beli</a>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ira Ramadhanty\Documents\smk\kls 12\usk\fintech_usk\resources\views/transaksi.blade.php ENDPATH**/ ?>