

<?php
$page = 'Top Up';
?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card" style="border-radius: 20px">
                    <div class="card-header" style="background-color: #8DA0F5; border-radius: 10px">Top Up</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <h4>SALDO : <b><?php echo e($saldo->saldo); ?></b></h4>

                        <form method="POST" action="<?php echo e(route('transaksi.create')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mt-4">
                                <label>Amount</label>
                                <input type="number" name="jumlah" class="form-control" placeholder="Nominal Input">
                                <input type="hidden" name="type" value="1">
                            </div>
                            <button class="btn btn-primary mt-5" type="submit">Top Up</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ira Ramadhanty\Documents\smk\kls 12\usk\fintech_usk\resources\views/topup.blade.php ENDPATH**/ ?>