

<?php
$page = 'Home';
?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card" style="border-radius:15px">
                    <div class="card-header" style="color: white;background-color: #5D73D5;font-weight:bold;font-size:20px;border-radius:10px"><?php echo e(__('Dashboard')); ?>

                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(Auth::user()->role_id === 1): ?>
                            <div class="row">
                                <div class="card col" style="width: 100px; height: 100px; align-items:center; justify-content:center; margin:5px; background-color: #95B3ED">
                                    <a href="<?php echo e(route('data_user')); ?>"
                                        style="color: white;text-decoration:none;font-size:18px">User
                                        List</a>
                                </div>
                                <div class="card col" style="width: 100px; height: 100px; align-items:center; justify-content:center; margin:5px; background-color: #95B3ED">
                                    <a href="<?php echo e(route('data_transaksi')); ?>"
                                        style="color: white;text-decoration:none;font-size:18px">Transaksi</a>
                                </div>
                            </div>  
                        <?php endif; ?>
                        <?php if(Auth::user()->role_id === 4): ?>
                            <div class="row">
                                <div class="card col" style="width: 100px; height: 100px; align-items:center; justify-content:center; margin:5px; background-color: #95B3ED">
                                    <a href="<?php echo e(route('topup')); ?>"
                                        style="color: white;text-decoration:none;font-size:18px">Top Up</a>
                                </div>
                                <div class="card col" style="width: 100px; height: 100px; align-items:center; justify-content:center; margin:5px; background-color: #95B3ED">
                                    <a href="<?php echo e(route('transaksi')); ?>"
                                        style="color: white;text-decoration:none;font-size:18px">Canteen</a>
                                </div>
                            </div>  
                        <?php endif; ?>
                        <?php if(Auth::user()->role_id === 2): ?>
                            <table class="table table-bordered border-dark table-striped">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>Nominal</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pengajuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pengajuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($pengajuan->user->name); ?></td>
                                            <td><?php echo e($pengajuan->jumlah); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('topup.setuju', ['transaksi_id' => $pengajuan->id])); ?>"
                                                    class="btn btn-primary">
                                                    Accept
                                                </a>
                                                <a href="<?php echo e(route('topup.tolak', ['transaksi_id' => $pengajuan->id])); ?>"
                                                    class="btn btn-danger">
                                                    Decline
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                        <?php if(Auth::user()->role_id === 3): ?>
                            <table class="table table-bordered border-dark table-striped">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        
                                        <th>Invoice ID</th>
                                        <th>Status</th>
                                        <th>Detail</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $jajan_by_invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $jajan_by_invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($jajan_by_invoice->status == 2 || $jajan_by_invoice->status == 3): ?>
                                            <tr>
                                                <td><?php echo e($key + 1); ?></td>
                                                <td><?php echo e($jajan_by_invoice->user->name); ?></td>
                                                <td><?php echo e($jajan_by_invoice->invoice_id); ?></td>
                                                
                                                <td><?php echo e($jajan_by_invoice->status == 2 ? 'Pending' : 'Completed'); ?></td>
                                                <td>
                                                    <!-- Button trigger modal -->
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#detail-<?php echo e($jajan_by_invoice->invoice_id); ?>">
                                                        Detail
                                                    </button>

                                                    <!-- Modal -->
                                                    <div class="modal fade"
                                                        id="detail-<?php echo e($jajan_by_invoice->invoice_id); ?>" tabindex="-1"
                                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">
                                                                        Order #<?php echo e($jajan_by_invoice->invoice_id); ?></h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <table class="table table-bordered border-dark table-striped">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>No.</th>
                                                                                <th>Menu</th>
                                                                                <th>Qty</th>
                                                                                <th>Price</th>
                                                                                <th>Total</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <?php
                                                                            $counter = 1;
                                                                            $total_harga = 0;
                                                                            ?>
                                                                            <?php $__currentLoopData = $pengajuan_jajans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengajuan_jajan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($pengajuan_jajan->invoice_id == $jajan_by_invoice->invoice_id): ?>
                                                                                    <?php $total_harga += $pengajuan_jajan->jumlah * $pengajuan_jajan->barang->price; ?>
                                                                                    <tr>
                                                                                        <td><?php echo e($counter++); ?></td>
                                                                                        <td><?php echo e($pengajuan_jajan->barang->name); ?>

                                                                                        </td>
                                                                                        <td><?php echo e($pengajuan_jajan->jumlah); ?>

                                                                                        </td>
                                                                                        <td><?php echo e($pengajuan_jajan->barang->price); ?>

                                                                                        </td>
                                                                                        <td><?php echo e($pengajuan_jajan->jumlah * $pengajuan_jajan->barang->price); ?>

                                                                                        </td>
                                                                                    </tr>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </tbody>
                                                                    </table>
                                                                    Total = <?php echo e($total_harga); ?>

                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Close</button>
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php if($jajan_by_invoice->status == 3): ?>
                                                        <a href="<?php echo e(route('jajan.setuju', ['invoice_id' => $jajan_by_invoice->invoice_id])); ?>"
                                                            class="btn btn-primary">
                                                            Accept
                                                        </a>
                                                        <a href="<?php echo e(route('jajan.tolak', ['invoice_id' => $jajan_by_invoice->invoice_id])); ?>"
                                                            class="btn btn-danger">
                                                            Decline
                                                        </a>
                                                    <?php else: ?>
                                                        Menunggu Pembayaran
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ira Ramadhanty\Documents\smk\kls 12\usk\fintech_usk\resources\views/home.blade.php ENDPATH**/ ?>